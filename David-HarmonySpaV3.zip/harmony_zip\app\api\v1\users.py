"""Endpoints de usuarios: /api/v1/users/...

Dos grupos:
  - /users/me...   cualquier usuario autenticado (su propio perfil).
  - /users, /users/{id}   solo SUPER_ADMIN y ADMIN (gestión de otros usuarios).

Las reglas finas (quién puede editar a quién) están en services/user_service.py
y core/permissions.py. Importante: las rutas /me se declaran ANTES que
/{user_id}, para que "me" no se interprete como un id.
"""

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session

from app.api.deps import AuthContext, get_auth_context, get_current_user, require_roles
from app.domain.enums.user_role import UserRole
from app.infrastructure.database.session import get_db
from app.models import User
from app.schemas import (
    ChangePasswordRequest,
    MessageResponse,
    UserCreate,
    UserListResponse,
    UserRead,
    UserSelfUpdate,
    UserUpdate,
)
from app.services import UserService

router = APIRouter(prefix="/users", tags=["Usuarios"])

# SUPER_ADMIN y ADMIN administran usuarios; el resto de reglas finas
# (a quién pueden gestionar y qué roles asignar) viven en app/core/permissions.py
# Atajo: dependencia que exige rol SUPER_ADMIN o ADMIN.
admin_only = require_roles(UserRole.SUPER_ADMIN, UserRole.ADMIN)


# --- Perfil propio (declarado antes de /{user_id} para que "me" no se confunda con un id) ---
@router.get("/me", response_model=UserRead, summary="Ver mi perfil")
def get_me(user: User = Depends(get_current_user)) -> UserRead:
    return UserRead.model_validate(user)


@router.patch("/me", response_model=UserRead, summary="Editar mi perfil")
def update_me(
    payload: UserSelfUpdate,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> UserRead:
    return UserRead.model_validate(UserService(db).update_me(user, payload))


@router.post(
    "/me/password",
    response_model=MessageResponse,
    summary="Cambiar mi contraseña",
)
def change_my_password(
    payload: ChangePasswordRequest,
    ctx: AuthContext = Depends(get_auth_context),
    db: Session = Depends(get_db),
) -> MessageResponse:
    UserService(db).change_password(
        ctx.user,
        current_password=payload.current_password,
        new_password=payload.new_password,
        current_jti=ctx.session.jti,
    )
    return MessageResponse(
        message="Contraseña actualizada. Las demás sesiones fueron cerradas."
    )


# --- Administración de usuarios ---
@router.post(
    "",
    response_model=UserRead,
    status_code=status.HTTP_201_CREATED,
    summary="Crear usuario",
)
def create_user(
    payload: UserCreate,
    actor: User = Depends(admin_only),
    db: Session = Depends(get_db),
) -> UserRead:
    return UserRead.model_validate(UserService(db).create_user(actor, payload))


@router.get("", response_model=UserListResponse, summary="Listar usuarios")
def list_users(
    role: UserRole | None = None,
    is_active: bool | None = None,
    search: str | None = Query(default=None, max_length=100),
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=20, ge=1, le=100),
    _actor: User = Depends(admin_only),
    db: Session = Depends(get_db),
) -> UserListResponse:
    items, total = UserService(db).list_users(
        role=role,
        is_active=is_active,
        search=search,
        skip=skip,
        limit=limit,
    )
    return UserListResponse(
        items=[UserRead.model_validate(item) for item in items],
        total=total,
        skip=skip,
        limit=limit,
    )


@router.get("/{user_id}", response_model=UserRead, summary="Ver un usuario")
def get_user(
    user_id: int,
    _actor: User = Depends(admin_only),
    db: Session = Depends(get_db),
) -> UserRead:
    return UserRead.model_validate(UserService(db).get_user(user_id))


@router.patch("/{user_id}", response_model=UserRead, summary="Editar un usuario")
def update_user(
    user_id: int,
    payload: UserUpdate,
    actor: User = Depends(admin_only),
    db: Session = Depends(get_db),
) -> UserRead:
    return UserRead.model_validate(UserService(db).update_user(actor, user_id, payload))


@router.delete(
    "/{user_id}",
    response_model=UserRead,
    summary="Desactivar un usuario (borrado lógico)",
)
def deactivate_user(
    user_id: int,
    actor: User = Depends(admin_only),
    db: Session = Depends(get_db),
) -> UserRead:
    return UserRead.model_validate(UserService(db).deactivate_user(actor, user_id))
