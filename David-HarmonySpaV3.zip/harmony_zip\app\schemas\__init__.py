"""Esquemas Pydantic: forma de los datos que entran y salen de la API.

Validan el JSON recibido (ej. LoginRequest) y definen lo que se devuelve
(ej. UserRead, que nunca incluye password_hash).
"""

from app.schemas.auth import LoginRequest, MessageResponse, TokenResponse
from app.schemas.user import (
    ChangePasswordRequest,
    UserCreate,
    UserListResponse,
    UserRead,
    UserSelfUpdate,
    UserUpdate,
)

__all__ = [
    "ChangePasswordRequest",
    "LoginRequest",
    "MessageResponse",
    "TokenResponse",
    "UserCreate",
    "UserListResponse",
    "UserRead",
    "UserSelfUpdate",
    "UserUpdate",
]
