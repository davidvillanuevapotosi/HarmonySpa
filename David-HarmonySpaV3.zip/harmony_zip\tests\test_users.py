from sqlalchemy.exc import IntegrityError

from app.core.security import hash_password
from app.domain.enums.user_role import UserRole
from app.infrastructure.database.session import SessionLocal
from app.models import User
from app.services import UserService
from tests.conftest import PASSWORD

USERS = "/api/v1/users"
LOGIN = "/api/v1/auth/login"
ME = "/api/v1/users/me"


def _new_user_payload(**overrides):
    payload = {
        "first_name": "Laura",
        "last_name": "Gómez",
        "email": "laura@harmonyspa.co",
        "phone": "+57 300 123 4567",
        "password": "ClaveSegura2026",
        "role": "CLIENTE",
    }
    payload.update(overrides)
    return payload


# --- Permisos de creación -------------------------------------------------
def test_super_admin_can_create_admin(client, make_user, login, auth):
    make_user(UserRole.SUPER_ADMIN, email="root@harmonyspa.co")
    token = login("root@harmonyspa.co")

    response = client.post(
        USERS, json=_new_user_payload(role="ADMIN"), headers=auth(token)
    )

    assert response.status_code == 201
    assert response.json()["role"] == "ADMIN"
    assert "password" not in response.json()


def test_admin_can_create_cliente_but_not_admin(client, make_user, login, auth):
    make_user(UserRole.ADMIN, email="admin@harmonyspa.co")
    token = login("admin@harmonyspa.co")

    ok = client.post(USERS, json=_new_user_payload(), headers=auth(token))
    denied = client.post(
        USERS,
        json=_new_user_payload(email="otro@harmonyspa.co", role="ADMIN"),
        headers=auth(token),
    )

    assert ok.status_code == 201
    assert denied.status_code == 403


def test_nobody_can_create_super_admin_through_api(client, make_user, login, auth):
    make_user(UserRole.SUPER_ADMIN, email="root@harmonyspa.co")
    token = login("root@harmonyspa.co")

    response = client.post(
        USERS, json=_new_user_payload(role="SUPER_ADMIN"), headers=auth(token)
    )

    assert response.status_code == 403


def test_cliente_and_esteticista_cannot_manage_users(client, make_user, login, auth):
    make_user(UserRole.CLIENTE, email="cliente@harmonyspa.co")
    make_user(UserRole.ESTETICISTA, email="esteticista@harmonyspa.co")

    for email in ("cliente@harmonyspa.co", "esteticista@harmonyspa.co"):
        headers = auth(login(email))
        assert client.get(USERS, headers=headers).status_code == 403
        assert client.post(USERS, json=_new_user_payload(), headers=headers).status_code == 403


def test_users_endpoints_require_authentication(client):
    assert client.get(USERS).status_code == 401
    assert client.post(USERS, json=_new_user_payload()).status_code == 401


# --- Validaciones ---------------------------------------------------------
def test_duplicate_email_returns_409(client, make_user, login, auth):
    make_user(UserRole.ADMIN, email="admin@harmonyspa.co")
    headers = auth(login("admin@harmonyspa.co"))

    first = client.post(USERS, json=_new_user_payload(), headers=headers)
    second = client.post(
        USERS, json=_new_user_payload(email="LAURA@harmonyspa.co"), headers=headers
    )

    assert first.status_code == 201
    assert second.status_code == 409


def test_weak_password_returns_422(client, make_user, login, auth):
    make_user(UserRole.ADMIN, email="admin@harmonyspa.co")
    headers = auth(login("admin@harmonyspa.co"))

    response = client.post(
        USERS, json=_new_user_payload(password="12345678"), headers=headers
    )

    assert response.status_code == 422


# --- Listado y consulta ---------------------------------------------------
def test_list_users_with_filters(client, make_user, login, auth):
    make_user(UserRole.ADMIN, email="admin@harmonyspa.co")
    make_user(UserRole.CLIENTE, email="ana@harmonyspa.co")
    make_user(UserRole.CLIENTE, email="beto@harmonyspa.co", is_active=False)
    make_user(UserRole.ESTETICISTA, email="eva@harmonyspa.co")
    headers = auth(login("admin@harmonyspa.co"))

    everyone = client.get(USERS, headers=headers).json()
    clientes = client.get(USERS, params={"role": "CLIENTE"}, headers=headers).json()
    activos = client.get(
        USERS, params={"role": "CLIENTE", "is_active": True}, headers=headers
    ).json()
    buscados = client.get(USERS, params={"search": "eva"}, headers=headers).json()
    paginado = client.get(USERS, params={"limit": 2}, headers=headers).json()

    assert everyone["total"] == 4
    assert clientes["total"] == 2
    assert activos["total"] == 1
    assert [u["email"] for u in buscados["items"]] == ["eva@harmonyspa.co"]
    assert len(paginado["items"]) == 2 and paginado["total"] == 4


def test_get_user_by_id_and_404(client, make_user, login, auth):
    make_user(UserRole.ADMIN, email="admin@harmonyspa.co")
    target = make_user(UserRole.CLIENTE, email="ana@harmonyspa.co")
    headers = auth(login("admin@harmonyspa.co"))

    assert client.get(f"{USERS}/{target.id}", headers=headers).json()["email"] == "ana@harmonyspa.co"
    assert client.get(f"{USERS}/99999", headers=headers).status_code == 404


# --- Edición y desactivación ---------------------------------------------
def test_admin_updates_cliente(client, make_user, login, auth):
    make_user(UserRole.ADMIN, email="admin@harmonyspa.co")
    target = make_user(UserRole.CLIENTE, email="ana@harmonyspa.co")
    headers = auth(login("admin@harmonyspa.co"))

    response = client.patch(
        f"{USERS}/{target.id}",
        json={"first_name": "  Ana María ", "phone": None, "role": "ESTETICISTA"},
        headers=headers,
    )

    assert response.status_code == 200
    body = response.json()
    assert body["first_name"] == "Ana María"
    assert body["phone"] is None
    assert body["role"] == "ESTETICISTA"


def test_admin_cannot_modify_admin_or_super_admin(client, make_user, login, auth):
    make_user(UserRole.ADMIN, email="admin@harmonyspa.co")
    other_admin = make_user(UserRole.ADMIN, email="admin2@harmonyspa.co")
    root = make_user(UserRole.SUPER_ADMIN, email="root@harmonyspa.co")
    headers = auth(login("admin@harmonyspa.co"))

    for target in (other_admin, root):
        response = client.patch(
            f"{USERS}/{target.id}", json={"first_name": "X"}, headers=headers
        )
        assert response.status_code == 403


def test_admin_cannot_promote_to_admin(client, make_user, login, auth):
    make_user(UserRole.ADMIN, email="admin@harmonyspa.co")
    target = make_user(UserRole.CLIENTE, email="ana@harmonyspa.co")
    headers = auth(login("admin@harmonyspa.co"))

    response = client.patch(
        f"{USERS}/{target.id}", json={"role": "ADMIN"}, headers=headers
    )

    assert response.status_code == 403


def test_update_rejects_null_for_required_fields(client, make_user, login, auth):
    make_user(UserRole.ADMIN, email="admin@harmonyspa.co")
    target = make_user(UserRole.CLIENTE, email="ana@harmonyspa.co")
    headers = auth(login("admin@harmonyspa.co"))

    response = client.patch(
        f"{USERS}/{target.id}", json={"first_name": None}, headers=headers
    )

    assert response.status_code == 422


def test_deactivating_user_kills_sessions_and_blocks_login(client, make_user, login, auth):
    make_user(UserRole.ADMIN, email="admin@harmonyspa.co")
    target = make_user(UserRole.CLIENTE, email="ana@harmonyspa.co")
    admin_headers = auth(login("admin@harmonyspa.co"))
    target_token = login("ana@harmonyspa.co")

    response = client.delete(f"{USERS}/{target.id}", headers=admin_headers)

    assert response.status_code == 200
    assert response.json()["is_active"] is False
    assert client.get(ME, headers=auth(target_token)).status_code == 401
    assert (
        client.post(LOGIN, json={"email": "ana@harmonyspa.co", "password": PASSWORD}).status_code
        == 403
    )


# --- Perfil propio --------------------------------------------------------
def test_update_my_profile_cannot_change_role(client, make_user, login, auth):
    make_user(UserRole.CLIENTE, email="ana@harmonyspa.co")
    headers = auth(login("ana@harmonyspa.co"))

    response = client.patch(
        ME, json={"first_name": "Ana", "role": "ADMIN"}, headers=headers
    )

    assert response.status_code == 200
    assert response.json()["first_name"] == "Ana"
    assert response.json()["role"] == "CLIENTE"


def test_change_password_flow(client, make_user, login, auth):
    make_user(UserRole.CLIENTE, email="ana@harmonyspa.co")
    token_current = login("ana@harmonyspa.co")
    token_other = login("ana@harmonyspa.co")
    headers = auth(token_current)

    wrong = client.post(
        f"{ME}/password",
        json={"current_password": "Incorrecta1", "new_password": "NuevaClave2026"},
        headers=headers,
    )
    same = client.post(
        f"{ME}/password",
        json={"current_password": PASSWORD, "new_password": PASSWORD},
        headers=headers,
    )
    ok = client.post(
        f"{ME}/password",
        json={"current_password": PASSWORD, "new_password": "NuevaClave2026"},
        headers=headers,
    )

    assert wrong.status_code == 400
    assert same.status_code == 400
    assert ok.status_code == 200
    # La sesión actual sigue activa; las demás se cierran.
    assert client.get(ME, headers=auth(token_current)).status_code == 200
    assert client.get(ME, headers=auth(token_other)).status_code == 401
    # La contraseña anterior ya no sirve.
    assert (
        client.post(LOGIN, json={"email": "ana@harmonyspa.co", "password": PASSWORD}).status_code
        == 401
    )
    assert (
        client.post(LOGIN, json={"email": "ana@harmonyspa.co", "password": "NuevaClave2026"}).status_code
        == 200
    )


# --- SUPER_ADMIN único ----------------------------------------------------
def test_create_super_admin_service_only_once():
    from app.core.exceptions import ConflictError
    import pytest

    with SessionLocal() as db:
        user = UserService(db).create_super_admin(
            first_name="Super",
            last_name="Admin",
            email="root@harmonyspa.co",
            password=PASSWORD,
        )
        assert user.role == UserRole.SUPER_ADMIN

    with SessionLocal() as db:
        with pytest.raises(ConflictError):
            UserService(db).create_super_admin(
                first_name="Otro",
                last_name="Admin",
                email="otro@harmonyspa.co",
                password=PASSWORD,
            )


def test_database_allows_only_one_super_admin():
    import pytest

    def _insert(email: str) -> None:
        with SessionLocal() as db:
            db.add(
                User(
                    first_name="S",
                    last_name="A",
                    email=email,
                    password_hash=hash_password(PASSWORD),
                    role=UserRole.SUPER_ADMIN,
                    is_active=True,
                )
            )
            db.commit()

    _insert("uno@harmonyspa.co")
    with pytest.raises(IntegrityError):
        _insert("dos@harmonyspa.co")
