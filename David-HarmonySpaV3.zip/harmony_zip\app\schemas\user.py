"""Esquemas de usuarios: crear, editar, cambiar contraseña y leer.

La política de contraseñas NO se repite aquí: se reutiliza
`validate_password_strength` de app/core/security.py.
"""

import re
from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from app.core.security import validate_password_strength
from app.domain.enums.user_role import UserRole

_PHONE_PATTERN = re.compile(r"^\+?[0-9\s\-()]{7,30}$")


def _clean_name(value: str) -> str:
    value = value.strip()
    if not value:
        raise ValueError("No puede estar vacío")
    return value


def _clean_phone(value: str | None) -> str | None:
    if value is None:
        return None
    value = value.strip()
    if not value:
        return None
    if not _PHONE_PATTERN.match(value):
        raise ValueError("Teléfono inválido")
    return value


class UserCreate(BaseModel):
    """Cuerpo de POST /users (lo crea un SUPER_ADMIN o ADMIN)."""

    first_name: str = Field(min_length=1, max_length=100)
    last_name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    phone: str | None = Field(default=None, max_length=30)
    password: str = Field(max_length=128)
    role: UserRole

    @field_validator("first_name", "last_name")
    @classmethod
    def clean_names(cls, value: str) -> str:
        return _clean_name(value)

    @field_validator("email")
    @classmethod
    def lower_email(cls, value: str) -> str:
        return value.strip().lower()

    @field_validator("phone")
    @classmethod
    def clean_phone(cls, value: str | None) -> str | None:
        return _clean_phone(value)

    @field_validator("password")
    @classmethod
    def check_password(cls, value: str) -> str:
        return validate_password_strength(value)


class _NoNullFieldsMixin(BaseModel):
    """Impide enviar null explícito en campos que son obligatorios en la BD."""

    @field_validator(
        "first_name", "last_name", "role", "is_active", mode="before", check_fields=False
    )
    @classmethod
    def reject_null(cls, value):
        if value is None:
            raise ValueError("No puede ser null")
        return value


class UserUpdate(_NoNullFieldsMixin):
    """Edición de un usuario por un administrador (todos los campos opcionales)."""

    first_name: str | None = Field(default=None, min_length=1, max_length=100)
    last_name: str | None = Field(default=None, min_length=1, max_length=100)
    phone: str | None = Field(default=None, max_length=30)
    role: UserRole | None = None
    is_active: bool | None = None

    @field_validator("first_name", "last_name")
    @classmethod
    def clean_names(cls, value: str | None) -> str | None:
        return None if value is None else _clean_name(value)

    @field_validator("phone")
    @classmethod
    def clean_phone(cls, value: str | None) -> str | None:
        return _clean_phone(value)


class UserSelfUpdate(_NoNullFieldsMixin):
    """Edición del propio perfil (no permite cambiar rol ni estado)."""

    first_name: str | None = Field(default=None, min_length=1, max_length=100)
    last_name: str | None = Field(default=None, min_length=1, max_length=100)
    phone: str | None = Field(default=None, max_length=30)

    @field_validator("first_name", "last_name")
    @classmethod
    def clean_names(cls, value: str | None) -> str | None:
        return None if value is None else _clean_name(value)

    @field_validator("phone")
    @classmethod
    def clean_phone(cls, value: str | None) -> str | None:
        return _clean_phone(value)


class ChangePasswordRequest(BaseModel):
    """Cuerpo de POST /users/me/password."""

    current_password: str = Field(min_length=1, max_length=128)
    new_password: str = Field(max_length=128)

    @field_validator("new_password")
    @classmethod
    def check_password(cls, value: str) -> str:
        return validate_password_strength(value)


class UserRead(BaseModel):
    """Usuario tal como lo devuelve la API (sin password_hash)."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    first_name: str
    last_name: str
    email: str
    phone: str | None
    role: UserRole
    is_active: bool
    created_at: datetime
    updated_at: datetime


class UserListResponse(BaseModel):
    """Respuesta paginada de GET /users."""

    items: list[UserRead]
    total: int
    skip: int
    limit: int
