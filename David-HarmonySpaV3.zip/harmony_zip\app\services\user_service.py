"""Servicio de usuarios: crear, listar, editar, desactivar y cambiar contraseña.

Aquí viven las reglas de negocio de los usuarios. Los permisos por rol se
consultan en app/core/permissions.py; los datos se leen/escriben mediante
UserRepository y SessionRepository.
"""

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.exceptions import (
    BadRequestError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
)
from app.core.permissions import assignable_roles, can_manage
from app.core.security import hash_password, verify_password
from app.domain.enums.user_role import UserRole
from app.models import User
from app.models.user import utc_now_naive
from app.repositories import SessionRepository, UserRepository
from app.schemas import UserCreate, UserSelfUpdate, UserUpdate


class UserService:
    """Reglas de negocio para la gestión de usuarios."""

    def __init__(self, db: Session) -> None:
        self.db = db
        self.users = UserRepository(db)
        self.sessions = SessionRepository(db)

    # ------------------------------------------------------------------
    # SUPER_ADMIN (solo desde scripts/create_super_admin.py)
    # ------------------------------------------------------------------
    def create_super_admin(
        self,
        *,
        first_name: str,
        last_name: str,
        email: str,
        password: str,
    ) -> User:
        """Crea el único SUPER_ADMIN. NO hay endpoint que llame a este método.

        Lo usa solo el script `python -m scripts.create_super_admin`.
        Doble protección contra duplicados: esta comprobación y, por debajo,
        la restricción UNIQUE de MySQL (`users.super_admin_slot`).
        """
        if self.users.get_super_admin() is not None:
            raise ConflictError("Ya existe un SUPER_ADMIN en el sistema")

        return self._create(
            first_name=first_name,
            last_name=last_name,
            email=email,
            phone=None,
            password=password,
            role=UserRole.SUPER_ADMIN,
        )

    # ------------------------------------------------------------------
    # Gestión de usuarios (API)
    # ------------------------------------------------------------------
    def create_user(self, actor: User, data: UserCreate) -> User:
        """Crea un usuario. `actor` solo puede asignar los roles que permite
        `assignable_roles` (SUPER_ADMIN nunca es asignable por la API)."""
        if data.role not in assignable_roles(actor.role):
            raise ForbiddenError(
                f"No tienes permiso para crear usuarios con el rol {data.role.value}"
            )

        return self._create(
            first_name=data.first_name,
            last_name=data.last_name,
            email=data.email,
            phone=data.phone,
            password=data.password,
            role=data.role,
        )

    def list_users(
        self,
        *,
        role: UserRole | None,
        is_active: bool | None,
        search: str | None,
        skip: int,
        limit: int,
    ) -> tuple[list[User], int]:
        """Lista usuarios filtrados; devuelve (página, total)."""
        return self.users.list_filtered(
            role=role,
            is_active=is_active,
            search=search,
            skip=skip,
            limit=limit,
        )

    def get_user(self, user_id: int) -> User:
        """Obtiene un usuario o lanza 404 si no existe."""
        user = self.users.get_by_id(user_id)
        if user is None:
            raise NotFoundError("Usuario no encontrado")
        return user

    def update_user(self, actor: User, user_id: int, data: UserUpdate) -> User:
        """Edita a otro usuario (PATCH /users/{id}).

        Reglas: el actor debe tener rango mayor que el objetivo y solo puede
        asignar roles permitidos. Si queda desactivado, se cierran sus sesiones.
        """
        target = self.get_user(user_id)

        if not can_manage(actor.role, target.role):
            raise ForbiddenError("No tienes permiso para modificar a este usuario")

        changes = data.model_dump(exclude_unset=True)

        new_role = changes.get("role")
        if new_role is not None and new_role != target.role:
            if new_role not in assignable_roles(actor.role):
                raise ForbiddenError(
                    f"No tienes permiso para asignar el rol {new_role.value}"
                )

        for field, value in changes.items():
            setattr(target, field, value)

        if changes.get("is_active") is False:
            # Un usuario desactivado pierde todas sus sesiones abiertas.
            self.sessions.revoke_all_for_user(target.id, utc_now_naive())

        self.db.commit()
        self.db.refresh(target)
        return target

    def deactivate_user(self, actor: User, user_id: int) -> User:
        """Borrado lógico: no elimina la fila, solo pone is_active = False."""
        return self.update_user(actor, user_id, UserUpdate(is_active=False))

    # ------------------------------------------------------------------
    # Perfil propio
    # ------------------------------------------------------------------
    def update_me(self, user: User, data: UserSelfUpdate) -> User:
        """Edita el propio perfil (nombre, apellido, teléfono). No permite rol/estado."""
        for field, value in data.model_dump(exclude_unset=True).items():
            setattr(user, field, value)

        self.db.commit()
        self.db.refresh(user)
        return user

    def change_password(
        self,
        user: User,
        *,
        current_password: str,
        new_password: str,
        current_jti: str,
    ) -> None:
        """Cambia la contraseña propia y cierra las demás sesiones.

        `current_jti` identifica la sesión actual, que se conserva abierta.
        """
        if not verify_password(current_password, user.password_hash):
            raise BadRequestError("La contraseña actual es incorrecta")

        if current_password == new_password:
            raise BadRequestError("La nueva contraseña debe ser distinta a la actual")

        user.password_hash = hash_password(new_password)
        # Se cierran las demás sesiones; la actual sigue activa.
        self.sessions.revoke_all_for_user(
            user.id, utc_now_naive(), except_jti=current_jti
        )
        self.db.commit()

    # ------------------------------------------------------------------
    # Internos
    # ------------------------------------------------------------------
    def _create(
        self,
        *,
        first_name: str,
        last_name: str,
        email: str,
        phone: str | None,
        password: str,
        role: UserRole,
    ) -> User:
        """Creación común a create_user y create_super_admin."""
        email = email.strip().lower()

        if self.users.get_by_email(email) is not None:
            raise ConflictError("El correo ya está registrado")

        user = User(
            first_name=first_name.strip(),
            last_name=last_name.strip(),
            email=email,
            phone=phone,
            # Se guarda el hash Argon2id, nunca la contraseña original.
            password_hash=hash_password(password),
            role=role,
            is_active=True,
        )

        try:
            self.users.add(user)
            self.db.commit()
        except IntegrityError as exc:
            # MySQL rechazó el registro (correo repetido o segundo SUPER_ADMIN),
            # por ejemplo si dos peticiones llegaron al mismo tiempo.
            self.db.rollback()
            raise ConflictError(
                "No se pudo crear el usuario: el correo ya existe o ya hay un SUPER_ADMIN"
            ) from exc

        self.db.refresh(user)
        return user
