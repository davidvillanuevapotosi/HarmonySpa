"""Modelos ORM (una clase = una tabla de MySQL).

Importarlos aquí permite `from app.models import User, UserSession` y,
sobre todo, que Alembic los registre en `Base.metadata` (migrations/env.py).
Al crear un modelo nuevo, agrégalo a este archivo.
"""

from app.models.user import User
from app.models.user_session import UserSession

__all__ = [
    "User",
    "UserSession",
]
